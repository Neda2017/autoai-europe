import evRoutes from "./routes/ev.js";
app.use("/api", evRoutes);
